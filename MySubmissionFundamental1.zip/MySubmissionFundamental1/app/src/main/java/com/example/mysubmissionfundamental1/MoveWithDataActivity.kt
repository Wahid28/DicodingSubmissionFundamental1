package com.example.mysubmissionfundamental1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView

class MoveWithDataActivity : AppCompatActivity() {

    companion object{
        const val EXTRA_USER = "extra_user"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_move_with_data)

        supportActionBar?.title = "Android Fundamental Sub-1 Wahid"

        val progressBar: ProgressBar = findViewById(R.id.progress_bar)
        progressBar.visibility = View.VISIBLE

        val nameReceived: TextView = findViewById(R.id.nama_user)
        val usernameReceived: TextView = findViewById(R.id.username_user)
        val followerReceived: TextView = findViewById(R.id.followers_user)
        val followingReceived: TextView = findViewById(R.id.following_user)
        val locationReceived: TextView = findViewById(R.id.location_user)
        val companyReceived: TextView = findViewById(R.id.company_user)
        val photoReceived: ImageView = findViewById(R.id.photo_user)
        val repositoryReceived:TextView = findViewById(R.id.repository_user)

        val user = intent.getParcelableExtra<User>(EXTRA_USER)

        nameReceived.text = user?.name
        followerReceived.text = user?.follower
        followingReceived.text = user?.following
        usernameReceived.text = "Username    : ${user?.username}"
        locationReceived.text = "Location       : ${user?.location}"
        companyReceived.text = "Company     : ${user?.company}"
        user?.photo?.let { photoReceived.setImageResource(it) }
        repositoryReceived.text = user?.repository

        progressBar.visibility = View.GONE
    }


}